package com.prasad.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.prasad.dto.OrderResponseDTO;
import com.prasad.service.SwiggyAppService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@RestController
@RequestMapping("/swiggy")
public class SwiggyAppController {

    @Autowired
    private SwiggyAppService service;

    @GetMapping("/home")
    public String greetingMessage() {
        return service.greeting();
    }

    @GetMapping("/{orderId}")
//	@CircuitBreaker(name="restaurantservice",fallbackMethod = "restaurantServiceGetMethod")
	@Retry(name="restaurantservice",fallbackMethod = "restaurantServiceGetMethod")
    public OrderResponseDTO checkOrderStatus(@PathVariable String orderId,@RequestHeader("loggedInUser") String username) {
    	System.out.println("The name who hits the Getmapping method in the Swiggy App microservice is "+username);
        return service.checkOrderStatus(orderId);
    }
    
	public OrderResponseDTO restaurantServiceGetMethod(Exception ex) {
		OrderResponseDTO dto = new OrderResponseDTO();
		dto.setStatus("Pending");
			return dto;
	}
}
