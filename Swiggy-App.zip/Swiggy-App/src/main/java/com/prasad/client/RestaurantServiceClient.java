package com.prasad.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.prasad.dto.OrderResponseDTO;

@Component
//@RefreshScope
public class RestaurantServiceClient {
	@Autowired
//	@Lazy
	private RestTemplate template;

//	@Value("${microservice.payment-service.endpoints.endpoint.uri}")
//	private String ENDPOINT_URL;
	
	public OrderResponseDTO fetchOrderStatus(String orderId) {
	//	System.out.println("ENDPOINT_URL from Cloud config servr : "+ENDPOINT_URL);
		return template.getForObject("http://RESTAURANT-SERVICE/restaurant/orders/status/" + orderId,OrderResponseDTO.class);
	//	return template.getForObject("ENDPOINT_URL" + orderId,
				
	}
}
